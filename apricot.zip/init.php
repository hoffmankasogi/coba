<?php

$general = array(

		//Nama Server
		"root_dir"=>"http://localhost/",
	    "didalamSubDomain"=>false,

	    /*
	    Ini merupakan sub directory root project kamu.
	    Misalnya, jika project kamu berada didalam 
	    http://localhost/web-saya/,
	    isi nilainya dengan "web-saya".

	    begitupun berada didalam 
	    http://domainkamu.com/folder/subfolder/
	    isi nilainya dengan "folder/subfolder"
	    */
		"sub_dir"=>"apricot",



		"encryption_key"=>"MDKUI68AtjUC3SMmUTZE1WeQQ7KMl0fN",


		/*
		WIB : Asia/Jakarta
		WITA : Asia/Makasar
		WIT: Asia/Jayapura
		 */
		"time_zone"=>"Asia/Jakarta", //WIB

		//pengaturan database
		"DB_hostname"=>"localhost",
		"DB_username"=>"root",
		"DB_password"=>"",
		"DB_database"=>"db"
	);
